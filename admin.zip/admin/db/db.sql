-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 10, 2017 at 08:03 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `zoho`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminid` double NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `logindate` datetime NOT NULL,
  `username` varchar(250) NOT NULL DEFAULT '',
  `password` varchar(250) NOT NULL DEFAULT '',
  `email` varchar(250) NOT NULL DEFAULT '',
  `user_type` int(2) NOT NULL COMMENT '0->Super Admin,1->Employee',
  `Created_date` date NOT NULL,
  `Modify_date` date NOT NULL,
  `Created_Id` int(11) NOT NULL,
  `Modify_Id` int(11) NOT NULL,
  `status` int(2) NOT NULL DEFAULT '1' COMMENT '0-inactive,1-active,2-deleted'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminid`, `firstname`, `lastname`, `logindate`, `username`, `password`, `email`, `user_type`, `Created_date`, `Modify_date`, `Created_Id`, `Modify_Id`, `status`) VALUES
(1, 'admin', 'admin', '2017-03-10 20:02:00', 'admin', '0192023a7bbd73250516f069df18b500', 'dharmesh1809@gmail.com', 0, '2011-08-16', '2013-08-08', 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `rollmanagement`
--

CREATE TABLE `rollmanagement` (
  `Id` int(11) NOT NULL,
  `Emp_Id` int(11) NOT NULL,
  `mainsection` varchar(100) NOT NULL,
  `subsection` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(500) NOT NULL,
  `image1` varchar(500) NOT NULL,
  `image2` varchar(800) NOT NULL,
  `cr_date` datetime NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_products`
--

CREATE TABLE `tbl_products` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `item_code` varchar(100) NOT NULL,
  `image` varchar(500) NOT NULL,
  `main_image1` varchar(225) NOT NULL,
  `main_image2` varchar(255) NOT NULL,
  `list_image` text NOT NULL,
  `cr_date` datetime NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_section`
--

CREATE TABLE `tbl_section` (
  `Section_Id` int(11) NOT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Link` varchar(255) DEFAULT NULL,
  `Image` varchar(255) DEFAULT 'default.png',
  `Description` text,
  `Order_no` int(11) DEFAULT NULL,
  `page_name` varchar(255) NOT NULL,
  `section_name` varchar(255) NOT NULL,
  `status` tinyint(2) DEFAULT NULL COMMENT '0-inactive,1-active,2-deleted'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_section`
--

INSERT INTO `tbl_section` (`Section_Id`, `Name`, `Link`, `Image`, `Description`, `Order_no`, `page_name`, `section_name`, `status`) VALUES
(1, 'Dashboard', 'dashboard', 'dashboard.png', 'This is Dashboard Page...', 1, 'Dashboard', 'Manage Dashboard', 1),
(2, 'Master', 'setting', 'default.png', 'This is master section..', 15, 'Setting', 'Manage Setting', 1),
(62, 'Manage Products', 'manage_products', 'default.png', NULL, 1, 'Manage Products', 'Manage Products', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sectionlink`
--

CREATE TABLE `tbl_sectionlink` (
  `Subsection_Id` int(11) NOT NULL,
  `Section_Id` int(11) DEFAULT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `Link` varchar(255) DEFAULT NULL,
  `Image` varchar(255) NOT NULL DEFAULT 'default.png',
  `Order_no` int(11) DEFAULT NULL,
  `page_name` varchar(255) NOT NULL,
  `section_name` varchar(255) NOT NULL,
  `status` tinyint(2) DEFAULT NULL COMMENT '0-inactive,1-active,2-deleted'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_sectionlink`
--

INSERT INTO `tbl_sectionlink` (`Subsection_Id`, `Section_Id`, `Title`, `Link`, `Image`, `Order_no`, `page_name`, `section_name`, `status`) VALUES
(5, 2, 'Settings', 'setting', 'default.png', 6, 'Settings', 'Manage Settings', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_settings`
--

CREATE TABLE `tbl_settings` (
  `Id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL COMMENT 'site info email',
  `theme` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_settings`
--

INSERT INTO `tbl_settings` (`Id`, `email`, `theme`) VALUES
(1, 'test@gmail.com', 'screen_blue.css');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD UNIQUE KEY `adminid` (`adminid`);

--
-- Indexes for table `rollmanagement`
--
ALTER TABLE `rollmanagement`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_products`
--
ALTER TABLE `tbl_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_section`
--
ALTER TABLE `tbl_section`
  ADD PRIMARY KEY (`Section_Id`);

--
-- Indexes for table `tbl_sectionlink`
--
ALTER TABLE `tbl_sectionlink`
  ADD PRIMARY KEY (`Subsection_Id`);

--
-- Indexes for table `tbl_settings`
--
ALTER TABLE `tbl_settings`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adminid` double NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `rollmanagement`
--
ALTER TABLE `rollmanagement`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_products`
--
ALTER TABLE `tbl_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_section`
--
ALTER TABLE `tbl_section`
  MODIFY `Section_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;
--
-- AUTO_INCREMENT for table `tbl_sectionlink`
--
ALTER TABLE `tbl_sectionlink`
  MODIFY `Subsection_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tbl_settings`
--
ALTER TABLE `tbl_settings`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
