<div class="footer">
  <div class="footer_bg">
    <div class="bottom_content1">
      <div class="bottom_left">
        <div class="copy">&nbsp;&nbsp;Copyright © 2013 ProjectName</div>
      </div>
      <div class="bottom_right1"> Crafted by <a href="http://www.vrinsofts.com/" style="color:#ABABAB; text-decoration:none;">ME</a>.&nbsp;&nbsp;</div>
      <div class="clear"></div>
    </div>
  </div>
  <div class="clear"></div>
</div>
