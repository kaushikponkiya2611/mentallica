<?php 
		@session_start();
		include('../../models/db.php');
		include('../../models/common-model.php');
		include('../../includes/thumb_new.php');
		include('../../includes/resize-class.php');
		include('../common-controller.php');
		$database = new Connection();
		include('../../models/ajax-model.php');
		$modelObj = new AjaxModel();
		$upload_dir =$_SESSION['SITE_IMG_PATH']."product/";
		$upload_dirthumb =$_SESSION['SITE_IMG_PATH']."product/thumb/";
		$imagepath =$_SESSION['FRNT_DOMAIN_NAME']."upload/product/";
	if(isset($_POST['view']) && $_POST['view'] != ''){
		$id = $_POST['id'];
		$qry = "SELECT * FROM tbl_products where id = '".mysql_real_escape_string($id)."'";
		$result = $modelObj->fetchRow($qry);
	?>
	<table width="100%" border="0" cellspacing="0" cellpadding="0" style="font-size:13px"><tr class="white_bg">
						<td width="120" align="right" class="popup_listing_border"><strong>Title:</strong></td>
						<td width="11" height="37" align="left" class="popup_listing_border">&nbsp;</td>
						<td width="469" align="left" class="popup_listing_border"><?php echo stripslashes($result['title']) ?></td>
					  </tr><tr class="light_bg">
						<td width="120" align="right" class="popup_listing_border"><strong>Item Code:</strong></td>
						<td width="11" height="37" align="left" class="popup_listing_border">&nbsp;</td>
						<td width="469" align="left" class="popup_listing_border"><?php echo stripslashes($result['item_code']) ?></td>
					  </tr><tr class="white_bg">
						<td width="120" align="right" class="popup_listing_border"><strong>Image:</strong></td>
						<td width="11" height="37" align="left" class="popup_listing_border">&nbsp;</td>
						<td width="469" align="left" class="popup_listing_border"><img src="<?=$LOCATION['SITE_ADMIN']?>upload/image/thumb/<?php echo stripslashes($result['image']) ?>" height="50" width="50" /></td>
					  </tr><tr class="light_bg">
						<td width="120" align="right" class="popup_listing_border"><strong>Main Image1:</strong></td>
						<td width="11" height="37" align="left" class="popup_listing_border">&nbsp;</td>
						<td width="469" align="left" class="popup_listing_border"><img src="<?=$LOCATION['SITE_ADMIN']?>upload/image/thumb/<?php echo stripslashes($result['main_image1']) ?>" height="50" width="50" /></td>
					  </tr><tr class="white_bg">
						<td width="120" align="right" class="popup_listing_border"><strong>Main Image2:</strong></td>
						<td width="11" height="37" align="left" class="popup_listing_border">&nbsp;</td>
						<td width="469" align="left" class="popup_listing_border"><img src="<?=$LOCATION['SITE_ADMIN']?>upload/image/thumb/<?php echo stripslashes($result['main_image2']) ?>" height="50" width="50" /></td>
					  </tr><tr class="light_bg">
						<td width="120" align="right" class="popup_listing_border"><strong>List Image:</strong></td>
						<td width="11" height="37" align="left" class="popup_listing_border">&nbsp;</td>
						<td width="469" align="left" class="popup_listing_border"><img src="<?=$LOCATION['SITE_ADMIN']?>upload/image/thumb/<?php echo stripslashes($result['list_image']) ?>" height="50" width="50" /></td>
					  </tr></table>
	<?php 
	} 
	?>			
	<?php
	if(isset($_POST['statusactive']) && $_POST['statusactive'] != '')
	{
		$id = explode("," ,$_POST['active']);
		foreach($id as $k => $val)
		{
			$qry = "UPDATE  tbl_products SET status = 1 WHERE id = ".mysql_real_escape_string($val);
			$result =  $modelObj->runQuery($qry);
		}
	}
	?>
	<?php
	if(isset($_POST['statusinactive']) && $_POST['statusinactive'] != '')
	{
		$id = explode("," ,$_POST['inactive']);
		foreach($id as $k => $val)
		{
			$qry = "UPDATE  tbl_products SET status = 0 WHERE id = ".mysql_real_escape_string($val);
			$result =  $modelObj->runQuery($qry);
		}
	}
	?>
	<?php
	if(isset($_POST['deleselected']) && $_POST['deleselected'] != ''){
		$id = explode("," ,$_POST['delete']);
		foreach($id as $k => $val)
		{
			$qry = "UPDATE  tbl_products SET status = 2 WHERE id = ".mysql_real_escape_string($val);
			$result =  $modelObj->runQuery($qry);
		}
	}
	?>
	<?php
	
	
	function GetProductName($code){
		ini_set("allow_url_fopen", 1);
		$url = "https://crm.zoho.com/crm/private/json/Products/searchRecords?authtoken=2a686fae400506f8baee7337ac9bbe48&scope=crmapi&criteria=(((Inventory%20Number:$code)))";
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_URL, $url);
		$result = curl_exec($ch);
		curl_close($ch);
		$obj = json_decode($result,true);
		return $obj['response']['result']['Products']['row']['FL'][3]['content'];
	}
	
	
	function updateProductImage($pic1,$pic2,$pic3,$picall){
			$ch = curl_init('https://crm.zoho.com/crm/private/xml/Products/updateRecords?');
			curl_setopt($ch, CURLOPT_VERBOSE, 1);//standard i/o streams 
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);// Turn off the server and peer verification 
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE); 
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);//Set to return data to string ($response) 
			curl_setopt($ch, CURLOPT_POST, 1);
			$authtoken = "2a686fae400506f8baee7337ac9bbe48";
			$xmlData = "<Products><row no='1'>
			<FL val='Main Photo'>$pic1</FL> 
			<FL val='Main Photo1'>$pic2</FL> 
			<FL val='Main Photo2'>$pic3</FL> 
			<FL val='List Photos'>$picall</FL>
			</row></Products>";
			$xmlData2 = urlencode($xmlData);

			$query = "newFormat=1&authtoken={$authtoken}&scope=crmapi&id=745078000005564001&xmlData={$xmlData2}"; 
			curl_setopt($ch, CURLOPT_POSTFIELDS, $query);
			$response = curl_exec($ch); 
			curl_close($ch);
	}
	
	if(isset($_POST['hid_add']) && $_POST['hid_add'] != ''){
		
		$qry = "SELECT * FROM tbl_products WHERE item_code = '".mysql_real_escape_string(trim($_POST['txt_additem_code']))."' and status!=2 ";
		$result = $modelObj -> fetchRow($qry);
		
		if(GetProductName($_POST['txt_additem_code'])==''){
			echo "2";
		}else{
		
		if(strtolower(trim($result['item_code'])) == strtolower(trim($_POST['txt_additem_code'])))
		{
			$flag = 0;
		}
		else
		{
			$flag = 1;
		}
		
		if($flag == 1)
		{
			if(!dir($upload_dir))
			{
				mkdir($upload_dir);
			}
			if(!dir($upload_dirthumb))
			{
				mkdir($upload_dirthumb);
			}
			$insertimagearray=array();
			foreach($_FILES["txt_addimage"]["tmp_name"] as $key=>$value)
				{
					$tmpfile = $_FILES["txt_addimage"]["tmp_name"][$key];
					$newname = $_FILES["txt_addimage"]["name"][$key];				
					$insertimage="";
					if($_FILES["txt_addimage"]["tmp_name"][$key] != '')
					{
						$abc=date("dmyHis");
						$insertimage=$abc.$newname;
						if(move_uploaded_file($tmpfile, $upload_dir.$insertimage))
						{
						  $resizeObj_20 = new resize($upload_dir.$insertimage); 
						  $resizeObj_20 -> resizeImage(50, 50, 'exact');
						  $resizeObj_20 -> saveImage($upload_dirthumb.$insertimage,$upload_dir.$insertimage, 100);
						}
						$insertimagearray[] = $insertimage;
					}
				}
				$aryfinal =  array_slice($insertimagearray,3);
				$img1 = $imagepath.$insertimagearray[0];
				$img2 = $imagepath.$insertimagearray[1];
				$img3 = $imagepath.$insertimagearray[2];
				$imgall = $imagepath.implode(",$imagepath",$aryfinal);
				updateProductImage($img1,$img2,$img3,$imgall);
				$qry = "INSERT INTO tbl_products (title,item_code,image,main_image1,main_image2,list_image,cr_date,status) VALUES ('".GetProductName($_POST['txt_additem_code'])."','".clear_input($_POST['txt_additem_code'])."','".$insertimagearray[0]."','".$insertimagearray[1]."','".$insertimagearray[2]."','".implode(',',$aryfinal)."',NOW(),1)";
			$result = $modelObj->runQuery($qry);
			echo "1";
	   }
	   else
	   {
		 echo "0";
	   }
		}
	}
	?>
	<?php
	if(isset($_POST['statusid']) && $_POST['statusid'] != ''){
		$qry = "UPDATE  tbl_products SET status = ".mysql_real_escape_string($_POST['status'])." WHERE id = ".mysql_real_escape_string($_POST['statusid']);
		$result =  $modelObj->runQuery($qry);
	}
	?>
	<?php
	if(isset($_POST['hid_update']) && $_POST['hid_update'] != ''){
		$qry = "SELECT * FROM tbl_products WHERE title = '".mysql_real_escape_string(trim($_POST['txt_addtitle']))."' and status!=2 and id != '".$_POST['hid_userid']."'";
		$result = $modelObj -> fetchRow($qry);
		
		if(strtolower(trim($result['title'])) == strtolower(trim($_POST['txt_addtitle'])))
		{
			echo $errmsg = "0";
			$flag = 0;
		}
		else
		{
			$flag = 1;
		}
		$flag = 1;
		
		if($flag == 1)
		{if(isset($_FILES["txt_addimage"]["tmp_name"]))
				{
					$tmpfile = $_FILES["txt_addimage"]["tmp_name"];
					$newname = $_FILES["txt_addimage"]["name"];
					$imgname='';
					
					if($_FILES["txt_addimage"]["tmp_name"] != '')
					{
						$abc=date("dmyHis");
						$imgname=$abc.$newname;
						if(move_uploaded_file($tmpfile, $upload_dir.$imgname))
						{
						  $resizeObj_20 = new resize($upload_dir.$imgname); 
						  $resizeObj_20 -> resizeImage(50, 50, 'exact');
						  $resizeObj_20 -> saveImage($upload_dirthumb.$imgname,$upload_dir.$imgname, 100);
						}
						$qry_img="UPDATE  tbl_products SET image='".$imgname."' where id='".mysql_real_escape_string($_POST['hid_userid'])."' ";
						$res_img= $modelObj->runQuery($qry_img);
					}
				}if(isset($_FILES["txt_addmain_image1"]["tmp_name"]))
				{
					$tmpfile = $_FILES["txt_addmain_image1"]["tmp_name"];
					$newname = $_FILES["txt_addmain_image1"]["name"];
					$imgname='';
					
					if($_FILES["txt_addmain_image1"]["tmp_name"] != '')
					{
						$abc=date("dmyHis");
						$imgname=$abc.$newname;
						if(move_uploaded_file($tmpfile, $upload_dir.$imgname))
						{
						  $resizeObj_20 = new resize($upload_dir.$imgname); 
						  $resizeObj_20 -> resizeImage(50, 50, 'exact');
						  $resizeObj_20 -> saveImage($upload_dirthumb.$imgname,$upload_dir.$imgname, 100);
						}
						$qry_img="UPDATE  tbl_products SET main_image1='".$imgname."' where id='".mysql_real_escape_string($_POST['hid_userid'])."' ";
						$res_img= $modelObj->runQuery($qry_img);
					}
				}if(isset($_FILES["txt_addmain_image2"]["tmp_name"]))
				{
					$tmpfile = $_FILES["txt_addmain_image2"]["tmp_name"];
					$newname = $_FILES["txt_addmain_image2"]["name"];
					$imgname='';
					
					if($_FILES["txt_addmain_image2"]["tmp_name"] != '')
					{
						$abc=date("dmyHis");
						$imgname=$abc.$newname;
						if(move_uploaded_file($tmpfile, $upload_dir.$imgname))
						{
						  $resizeObj_20 = new resize($upload_dir.$imgname); 
						  $resizeObj_20 -> resizeImage(50, 50, 'exact');
						  $resizeObj_20 -> saveImage($upload_dirthumb.$imgname,$upload_dir.$imgname, 100);
						}
						$qry_img="UPDATE  tbl_products SET main_image2='".$imgname."' where id='".mysql_real_escape_string($_POST['hid_userid'])."' ";
						$res_img= $modelObj->runQuery($qry_img);
					}
				}if(isset($_FILES["txt_addlist_image"]["tmp_name"]))
				{
					$tmpfile = $_FILES["txt_addlist_image"]["tmp_name"];
					$newname = $_FILES["txt_addlist_image"]["name"];
					$imgname='';
					
					if($_FILES["txt_addlist_image"]["tmp_name"] != '')
					{
						$abc=date("dmyHis");
						$imgname=$abc.$newname;
						if(move_uploaded_file($tmpfile, $upload_dir.$imgname))
						{
						  $resizeObj_20 = new resize($upload_dir.$imgname); 
						  $resizeObj_20 -> resizeImage(50, 50, 'exact');
						  $resizeObj_20 -> saveImage($upload_dirthumb.$imgname,$upload_dir.$imgname, 100);
						}
						$qry_img="UPDATE  tbl_products SET list_image='".$imgname."' where id='".mysql_real_escape_string($_POST['hid_userid'])."' ";
						$res_img= $modelObj->runQuery($qry_img);
					}
				}$qry = "UPDATE tbl_products SET title = '".clear_input($_POST['txt_addtitle'])."',item_code = '".clear_input($_POST['txt_additem_code'])."' WHERE id = '".mysql_real_escape_string($_POST['hid_userid'])."'";
			$result = $modelObj->runQuery($qry);
			echo "1";
		}
		else
		{
			echo "0";
		}
	}
	?>
	<?php
	if(isset($_POST['viewdiv']) && $_POST['viewdiv'] != ''){
		$start = $_POST['prevnext'];
		$end = $_POST['row'];
		$orderby=$_POST['orderby'];
		
		if($_POST['search'] != '0')
		{if(trim($_POST['txt_srctitle']) != '')
						{
							$searchqry .="and title LIKE '%".mysql_real_escape_string(trim($_POST['txt_srctitle']))."%'";
							$_SESSION['srchqry'] =  $searchqry; 
						}if(trim($_POST['txt_srcitem_code']) != '')
						{
							$searchqry .="and item_code LIKE '%".mysql_real_escape_string(trim($_POST['txt_srcitem_code']))."%'";
							$_SESSION['srchqry'] =  $searchqry; 
						}$_SESSION['srchqry'] =  $_SESSION['srchqry']; 
			
			if($_POST['fieldname'] == '0')
			{
				$qry = "SELECT * FROM tbl_products where status!=2 ".$_SESSION['srchqry']." order by cr_date desc LIMIT $start,$end ";
			}
			else
			{
				$qry = "SELECT * FROM tbl_products where status!=2 ".$_SESSION['srchqry']." ORDER BY ".$_POST['fieldname']." ".$orderby." LIMIT $start,$end";
			}
			$qry11 = mysql_query("SELECT * FROM tbl_products where status!=2 ".$_SESSION['srchqry']."")or die(mysql_error());
		}
		else
		{
			if($_POST['fieldname'] == '0')
			{
				$qry = "SELECT * FROM tbl_products where status!=2 order by cr_date desc LIMIT $start,$end ";
			}
			else
			{
				$qry = "SELECT * FROM tbl_products where status!=2 ORDER BY ".$_POST['fieldname']." ".$orderby." LIMIT $start,$end";
			}	  
			$qry11 = mysql_query("SELECT * FROM tbl_products where status!=2 ")or die(mysql_error());
		}
		$result = $modelObj->fetchRows($qry);
		$totalrecords = mysql_num_rows($qry11);
		$noofrows_k = $end;
		$noofpages = ceil($totalrecords/$noofrows_k);
		if($_POST['first'] != 0)
		{
			$curr_page =   ceil($start/$noofrows_k);
		}
		else if($_POST['last'] != 0)
		{
			$curr_page = 0;
		}
		else
		{
			$curr_page = $_POST['curr_page'];
		}
		
	?>
	<script type="text/javascript">
	$(document).ready(function () {
		$(".showhide-account").click(function () {
			$(".account-content").slideToggle("fast");
			$(this).toggleClass("active");
			return false;
		});
	});
	
	$(document).ready(function () {
		$(".action-slider").click(function () {
			$("#actions-box-slider").slideToggle("fast");
			$(this).toggleClass("activated");
			return false;
		});
	});
	$(function(){
		$('input').checkBox();
		$('#toggle-all').click(function(){
		$('#toggle-all').toggleClass('toggle-checked');
		$('#form_manage_productview input[type=checkbox]').checkBox('toggle');
		return false;
		});
	});
	</script> 
	<form id="form_manage_productview" action="" name="form_manage_productview" method="post" enctype="multipart/form-data" onsubmit="return false">
	<div class="searchdiv">
	<table class="searchdiv" border="0" width="100%" cellpadding="0" cellspacing="0">
	   <tr>
		 <td width="13%" align="left">
		<?php
		if($result != ''){
		?>
		<div id="actions-box">
			<a href="" class="action-slider"></a>
			<div id="actions-box-slider">
				<a style="cursor:pointer" class="action-delete" onclick="deleteselected()" id="testCheck">Delete</a>
				<a style="cursor:pointer" class="action-delete" onclick="statusactive()" id="testCheck">Active</a>
				<a style="cursor:pointer" class="action-delete" onclick="statusinactive()" id="testCheck">Inactive</a>
			</div>
			<div class="clear"></div>
		</div>
		<?php } ?>
		</td>
		<td width="16%">&nbsp;</td>
		<td width="64%">&nbsp;</td>
		<td width="7%" align="right" valign="bottom"><input class="button_bg" type="button" value="Search" name="btn_search" onclick="show_search()"></td>
	   </tr>
	</table>
	</div>
	
	<table border="0" width="100%" cellpadding="0" cellspacing="0" id="product-table">
		<tr>
			  <th class="table-header-check"><a id="toggle-all" ></a> </th><th class="table-header-repeat line-left minwidth-1"> <a onclick="sortingbyfield('title','asc')" id="title" class="cursorpointer">Item code</a></th><th class="table-header-repeat line-left minwidth-1"> <a id="path" class="cursorpointer">Name</a></th><th class="table-header-repeat line-left minwidth-1"> <a id="path" class="cursorpointer">Main photo</a></th><th class="table-header-repeat line-left minwidth-1"> <a id="path" class="cursorpointer">Main photo1</a></th><th class="table-header-repeat line-left minwidth-1"> <a id="path" class="cursorpointer">Main photo2</a></th><th class="table-header-repeat line-left minwidth-1"> <a id="path" class="cursorpointer">List photos</a></th><th class="table-header-options line-left"><a>Options</a></th>
			</tr>
	<?php
	$i = 0;
	if($result != ''){
		foreach($result  as $k => $data){
		$i++;
		$imagexpload = explode(",",$data['list_image']);
				$pathimg = array();
				foreach($imagexpload as $value){
					$pathimg[] = $imagepath.$value;
				}
				$pathimload = implode(";<br/> ", $pathimg);
	?>
		<tr id="<?php echo $data['id']?>" class="<?php if($i%2==0){ echo "light_bg"; }else{ echo "white_bg"; } ?>" height="30">
			  <td><input  type="checkbox" name="chk_id" id="chk_id" value="<?php echo $data['id'];  ?>"/></td><td class="cursorpointer" onclick="edit('<?php echo $data['id'] ?>','<?php echo $_GET['pid']?>')"><?php echo $data['item_code']; ?></td><td><?php echo $data['title']; ?></td><td><?php echo $imagepath.$data['image']; ?></td><td><?php echo $imagepath.$data['main_image1']; ?></td><td><?php echo $imagepath.$data['main_image2']; ?></td><td><?php echo $pathimload; ?></td><td class="options-width" ><table>
				  <tr>
					<td><?php
							if($data['status'] == '1')
							{
							?>
						  <div id="d_<?=$data['id']?>"> <a id="s_<?=$data['id']?>" style="cursor:pointer;" title="Active" class="icon-active info-tooltip" onclick="changeStatus('<?=$data['id']?>');"></a> </div>
						  <input type="hidden" id="status_<?=$data['id']?>" name="status_<?=$data['id']?>" value="Active" />
						  <?php
							}
							else
							{
							?>
						  <div id="d_<?=$data['id']?>"> <a id="s_<?=$data['id']?>" style="cursor:pointer;" title="Inactive" class="icon-inactive info-tooltip" onclick="changeStatus('<?=$data['id']?>');"></a> </div>
						  <input type="hidden" id="status_<?=$data['id']?>" name="status_<?=$data['id']?>" value="Inactive" />
						  <?php
							}
							?>
					</td>
					<td><a style="cursor:pointer" title="View" class="icon-view info-tooltip" onclick="view('<?php echo $data['id'] ?>')"></a></td>
					<td><a style="cursor:pointer" title="Edit" class="icon-edit info-tooltip" onclick="edit('<?php echo $data['id'] ?>','<?php echo $_GET['pid']?>')"></a></td>
					<td><a style="cursor:pointer" title="Delete" class="icon-delete info-tooltip" onclick="deleteuser('<?php echo $data['id'] ?>')" ></a></td>
				  </tr>
				</table></td>
			</tr>
		<?php 
			} 
		 }
		 else
		 { 
		 ?>
			 <tr height="30">
			  <td colspan="8" align="center" style="color:#FF0000"><strong><?php echo "No manage product found."; ?></strong></td>
			</tr>
		 <?php 
		 }
		 ?>
		</table>
	
	<?php
	if($result != ''){
		echo $modelObj->ajaxpaging_advancesearch($start,$result_numrec,$curr_page,$noofpages,$noofrows_k,$end);
		
	  ?>
	<?php }else{ ?>
		<input type="hidden" name="sel_noofrow" id="sel_noofrow" value="5" />
	<?php } ?>
		<input type="hidden" name="hid_fieldname" id="hid_fieldname"    value="<?=$_POST['fieldname']?>"  />
		<input type="hidden" name="hidsearch" id="hidsearch" 
		value="<?php if($_POST['search'] != '0') echo '1'; else echo '0' ?>" />
		<input type="hidden" name="viewdiv" id="viewdiv" value="1" />
	</form>
	<?php 
	} ?>
	<?php
	if(isset($_POST['delete']) && $_POST['delete'] != ''){
			$qry = "UPDATE tbl_products SET status = 2 WHERE id = '".$_POST['id']."'";
			$result = $modelObj->runQuery($qry);
		  if($result){
			echo $successmsg = '1';
		  }else{
			echo $errmsg = '0';
		  }
	 }
	?>
	
	<?php
	if(isset($_POST['edit']) && $_POST['edit'] != ''){
		$qry = "SELECT * FROM tbl_products WHERE id = '".$_POST['id']."'";
		$data = $modelObj->fetchRow($qry);
		$qry_country="SELECT * FROM tbl_country WHERE status=1 order by countryName asc";
		$result_crty = $modelObj->fetchRows($qry_country);
		$qry_state="SELECT * FROM tbl_state WHERE status=1 order by stateName asc";
		$result_state= $modelObj->fetchRows($qry_state);
		$qry_city="SELECT * FROM tbl_city WHERE status=1 order by cityName asc";
		$result_city = $modelObj->fetchRows($qry_city);
		$qry_zcode="SELECT * FROM tbl_zipcode WHERE status=1 order by zipCode asc";
		$result_zcode = $modelObj->fetchRows($qry_zcode);
	?>
	<script type="text/javascript" src="<?=$LOCATION['SITE_ADMIN']?>views/javascripts/js/jquery.form.js"></script><form name="form_manage_productsadd" id="form_manage_productsadd" method="post" enctype="multipart/form-data" action="#" >
		<table border="0" cellpadding="0" cellspacing="0"  id="id-form" width="100%">
		<tr class="white_bg">
						<tr class="light_bg">
						<th>Item Code : </th>
						<td width="23%">
						<input class="input_box" type="text" name="txt_additem_code" id="txt_additem_code" value="<?php echo stripslashes($data['item_code']) ?>" onblur="checkfield(this)"><font class="required"> *</font>
						</td>
						<td id="errortxt_additem_code" width="57%">
						<label class="removerror error_new" id="error-innertxt_additem_code"></label>
						</td>
					</tr>
					<tr class="white_bg">
						<th>Image : </th>
						<td width="23%">
						<input type="file" class="input_box" name="txt_addimage[]" multiple id="txt_addimage" size="16" />
						</td>
						<td id="errortxt_addimage" width="57%">
						<label class="removerror error_new" id="error-innertxt_addimage"></label>
						</td>
					</tr><tr class="white_bg">
				<th>&nbsp;</th>
				<td valign="top">
				<?php 
				if($_POST['id'] !=0)
				{
				?>
					<input type="hidden" name="hid_userid" id="hid_userid" value="<?php echo $data['id'] ?>" />
					<input type="hidden" name="hid_update" id="hid_update" value="update" />
					<input class="button_bg" type="submit" value="Submit" name="btn_update" onclick="return updatedata()">
					<input class="button_bg" type="button" value="Cancel" name="btn_cancel" onclick="newdata()">
				<?php
				}
				else
				{
				?>
					<input type="hidden" name="hid_add" id="hid_add" value="add" />
					<input class="button_bg" type="submit" value="Submit" name="btn_save" onclick="return adddata()">
					<input class="button_bg" type="button" value="Cancel" name="btn_cancel" onclick="newdata()">
				<?php
				}
				?>
				</td>
				<td></td>
			</tr>
		</table>
		</form>
	<?php 
	  }
	?>
	<?php 
	if(isset($_POST['getstateid'])){
	$qry_s="SELECT * FROM tbl_state WHERE status =1 and countryId='".$_POST['getstateid']."' order by stateName asc";
	$result_s = $modelObj->fetchRows($qry_s);
	?>
	<select class="select_box"  name="" id="" onblur="checkfield(this)" onchange="getCities()">
		<option value="">Select State</option>
		<?php
			if($result_s != '')
			{
				foreach($result_s  as $k => $data1)
				{
					echo "<option value=".$data1['id'].">".ucwords(stripslashes($data1['stateName']))."</option>";
				}
			}
		?>
	</select><font class="required"> *</font>
	<?php
	}
	?>
	<?php 
	if(isset($_POST['getcityid'])){
	$qry_s="SELECT * FROM tbl_city WHERE status =1 and stateId='".$_POST['getcityid']."' order by cityName asc";
	$result_s = $modelObj->fetchRows($qry_s);
	?>
	<select class="select_box"  name="" id="" onblur="checkfield(this)" onchange="getZipCode()">
		<option value="">Select City</option>
		<?php
			if($result_s != '')
			{
				foreach($result_s  as $k => $data1)
				{
					echo "<option value=".$data1['id'].">".ucwords(stripslashes($data1['cityName']))."</option>";
				}
			}
		?>
	</select><font class="required"> *</font>
	<?php
	}
	?>
	<?php 
	if(isset($_POST['getzcodeid'])){
	$qry_s="SELECT * FROM tbl_zipcode WHERE status =1 and cityId='".$_POST['getzcodeid']."' order by zipCode asc";
	$result_s = $modelObj->fetchRows($qry_s);
	?>
	<select class="select_box"  name="" id="" onblur="checkfield(this)">
		<option value="">Select Zipcode</option>
		<?php
			if($result_s != '')
			{
				foreach($result_s  as $k => $data1)
				{
					echo "<option value=".$data1['id'].">".ucwords(stripslashes($data1['zipCode']))."</option>";
				}
			}
		?>
	</select><font class="required"> *</font>
	<?php
	}
	?>