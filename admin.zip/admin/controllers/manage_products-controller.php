<?php
	class Manage_productsController extends CommonController
	{
		function __construct()
		{
			parent::__construct();
			$this -> modelObj = new Manage_productsModel();
			$this->getmanage_products = $this->getManage_products();
			$this->gettotalpageno = $this->gettotalpageno();
		}
		
		function getManage_products(){
		  $qry="SELECT * FROM tbl_products where status!=2 order by cr_date desc LIMIT 0 , 20";
		  return $result = $this->modelObj->fetchRows($qry);
		}
		
		function gettotalpageno(){
		  $qry = "SELECT * FROM tbl_products where status!=2";
		  return $result = $this->modelObj->numRows($qry);
		}
	}
	?>