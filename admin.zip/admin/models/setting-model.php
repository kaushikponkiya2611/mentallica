<?php
class SettingModel extends CommonModel
{
}
?>