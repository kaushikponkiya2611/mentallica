<?php
class ManageMenuModel extends CommonModel
{
}
?>