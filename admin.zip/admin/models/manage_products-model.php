<?php 
class Manage_productsModel extends CommonModel
{
}
?>
