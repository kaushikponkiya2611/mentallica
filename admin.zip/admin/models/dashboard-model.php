<?php
class DashboardModel extends CommonModel
{
}
?>