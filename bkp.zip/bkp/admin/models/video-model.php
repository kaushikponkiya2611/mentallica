<?php 
class VideoModel extends CommonModel
{
}
?>
