<?php 
class CustomerModel extends CommonModel
{
}
?>
