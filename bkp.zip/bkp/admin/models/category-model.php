<?php 
class CategoryModel extends CommonModel
{
}
?>
