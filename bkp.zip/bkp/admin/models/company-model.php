<?php 
class CompanyModel extends CommonModel
{
}
?>
