<?php
class EmployeemanagementModel extends CommonModel
{
}
?>