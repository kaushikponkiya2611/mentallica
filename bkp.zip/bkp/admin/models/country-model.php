<?php 
class CountryModel extends CommonModel
{
}
?>
