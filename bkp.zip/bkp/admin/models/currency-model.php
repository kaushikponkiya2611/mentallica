<?php 
class CurrencyModel extends CommonModel
{
}
?>
