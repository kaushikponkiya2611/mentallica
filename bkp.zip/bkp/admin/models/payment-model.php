<?php 
class PaymentModel extends CommonModel
{
}
?>
