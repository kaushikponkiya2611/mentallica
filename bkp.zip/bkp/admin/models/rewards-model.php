<?php 
class RewardsModel extends CommonModel
{
}
?>
