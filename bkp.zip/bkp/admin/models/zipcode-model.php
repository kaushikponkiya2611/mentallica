<?php
class ZipcodeModel extends CommonModel
{
}
?>