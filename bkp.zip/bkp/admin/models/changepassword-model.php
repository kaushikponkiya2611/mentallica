<?php
class ChangepasswordModel extends CommonModel
{
}
?>