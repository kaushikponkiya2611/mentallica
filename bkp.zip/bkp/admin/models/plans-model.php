<?php 
class PlansModel extends CommonModel
{
}
?>
