<?php 
class OffersModel extends CommonModel
{
}
?>
