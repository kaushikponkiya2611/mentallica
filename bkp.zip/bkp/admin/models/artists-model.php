<?php 
class ArtistsModel extends CommonModel
{
}
?>
