<?php 
class CityModel extends CommonModel
{
}
?>
