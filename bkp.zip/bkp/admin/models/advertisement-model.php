<?php 
class AdvertisementModel extends CommonModel
{
}
?>
