<?php 
class StateModel extends CommonModel
{
}
?>
