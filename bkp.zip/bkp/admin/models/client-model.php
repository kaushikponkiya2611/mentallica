<?php 
class ClientModel extends CommonModel
{
}
?>
