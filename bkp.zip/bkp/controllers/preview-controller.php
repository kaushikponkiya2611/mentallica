<?php
class PreviewController extends CommonController
{
	function __construct()
	{
		parent::__construct();
		$this -> modelObj = new PreviewModel();
		
		$this -> getuserimages = $this -> getuserimages();
		$this -> getpreviewcategories = $this -> getpreviewcategories();
	}
	
	function getpreviewcategories(){
	  $qry="SELECT preview_category FROM tbl_users WHERE status = 1 AND id = ".$_SESSION['po_userses']['flc_usrlogin_id'];
      return $result = $this->modelObj->fetchRow($qry);
	}
}
?>