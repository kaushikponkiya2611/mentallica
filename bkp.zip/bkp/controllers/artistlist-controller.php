<?php
class ArtistlistController extends CommonController
{
	function __construct()
	{
		parent::__construct();
		$this -> modelObj = new ArtistlistModel();
		
		//$this -> homecategorylist = $this -> getcategorylist();

		if(!isset($_GET['workid']) || $_GET['workid'] == ''):
			$this -> redirecttohomepage();
		endif;

		$this -> artistlistbycategory = $this -> getartistbypreviewcategory($_GET['workid']);
	}

	function getartistbypreviewcategory($catid){
		
		$src_str = '';

		if(isset($_POST['src_first_name']) && $_POST['src_first_name'] != ''):
			$src_str .= " AND first_name LIKE '%".$_POST['src_first_name']."%' ";
		endif;
		if(isset($_POST['src_last_name']) && $_POST['src_last_name'] != ''):
			$src_str .= " AND last_name LIKE '%".$_POST['src_last_name']."%' ";
		endif;
		if(isset($_POST['src_gender']) && $_POST['src_gender'] != ''):
			$src_str .= " AND gender = '".$_POST['src_gender']."' ";
		endif;
		if(isset($_POST['src_email']) && $_POST['src_email'] != ''):
			$src_str .= " AND emailid LIKE '%".$_POST['src_email']."%' ";
		endif;
		if(isset($_POST['src_country']) && $_POST['src_country'] != ''):
			$src_str .= " AND country = '".$_POST['src_country']."' ";
		endif;
		if(isset($_POST['src_state']) && $_POST['src_state'] != ''):
			$src_str .= " AND state = '".$_POST['src_state']."' ";
		endif;

		$qry="SELECT id, image, first_name, last_name, username FROM tbl_users WHERE FIND_IN_SET('".$catid."', preview_category) and usertype = 1 and status = 1 ".$src_str;
		return $result = $this->modelObj->fetchRows($qry);
	}
}
?>