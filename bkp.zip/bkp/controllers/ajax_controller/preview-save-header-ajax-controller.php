<?php 
	@session_start();
	error_reporting(0);
	include('../../models/db.php');
	include('../../models/common-model.php');
	include('../../includes/thumb_new.php');
	include('../../includes/resize-class.php');
	include('../common-controller.php');
	$database = new Connection();
	include('../../models/ajax-model.php');
	$modelObj = new AjaxModel();
	$commoncont = new CommonController();
?>
<?php 
if(isset($_POST['content']) && $_POST['content'] != ''):
  
    $contentheader = $_POST['content'];
    $contentfooter = "";
    $contentsidebar = "";
    $usrdata = $_SESSION['po_userses']['flc_usrlogin_id'];

    if($contentheader != '' && $usrdata != ''){
        $chkifexist = $commoncont -> checkifpreviewheaderexist($usrdata);
        if($chkifexist == 0){
          $commoncont -> addpreviewpageheaderfootersidebar($usrdata, $contentheader, $contentfooter, $contentsidebar);
        }elseif($chkifexist > 0){
          $commoncont -> updatepreviewpageheader($usrdata, $contentheader);
        }
    }

    echo 1;
    exit;
endif;
?>