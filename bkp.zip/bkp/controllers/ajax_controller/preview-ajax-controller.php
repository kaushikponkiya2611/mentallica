<?php 
	@session_start();
	error_reporting(0);
	include('../../models/db.php');
	include('../../models/common-model.php');
	include('../../includes/thumb_new.php');
	include('../../includes/resize-class.php');
	include('../common-controller.php');
	$database = new Connection();
	include('../../models/ajax-model.php');
	$modelObj = new AjaxModel();
	$commoncont = new CommonController();
?>
<?php 
if(isset($_POST['setnewimageorederchk']) && $_POST['setnewimageorederchk'] != ''):
    $imgpos = $_POST['eleary'];
    foreach ($imgpos as $key => $impo) {
      $impodata = explode("|", $impo);
      $qry="UPDATE tbl_user_images SET image_rank = '".clear_input($impodata[1])."' WHERE id='".clear_input($impodata[0])."' ";
      $result = $modelObj->runQuery($qry); 
    }
    echo 1;
    exit;
endif;
if(isset($_POST['makeuserimagehiddenchk']) && $_POST['makeuserimagehiddenchk'] != ''):
    $tabval = $_POST['tabval'];
    
    $qry="UPDATE tbl_user_images SET status = 0 WHERE id='".clear_input($tabval)."' ";
    $result = $modelObj->runQuery($qry); 
    
    $userimgdetail = $commoncont -> getuserimagedetailbyid($tabval);
    //print_r($userimgdetail);
    $itemhtml = '<div class="col-lg-3 col-md-3 col-xs-6 preview-item ui-state-default" style="min-height: 225px; background-image: url(\''.$_SESSION['SITE_NAME'].'upload/images/300/'.$userimgdetail['image'].'\'); background-size: cover; background-repeat: no-repeat; background-position: 50% 50%;" data-backto="sortable'.$userimgdetail['category_id'].'" data-tabval="'.$userimgdetail['id'].'">
          <i class="fa fa-undo undo-cross" title="Restore image"></i>
          <a href="javascript:void(0)" onclick="openuserimageinpopup(\''.$userimgdetail['id'].'\')" class="openpop-link">&nbsp;</a>
          <!--<a>
              <img src="'.$_SESSION['SITE_NAME'].'upload/images/300/'.$userimgdetail['image'].'" alt="..." class="example-image img-responsive" />
          </a>

          <h3>
              '.$userimgdetail['img_title'].'
          </h3>  -->  

      </div>';
    echo $itemhtml;
    exit;
endif;
if(isset($_POST['moveitembacktocategorytabchk']) && $_POST['moveitembacktocategorytabchk'] != ''):
    $tabval = $_POST['tabval'];
    
    $qry="UPDATE tbl_user_images SET status = 1 WHERE id='".clear_input($tabval)."' ";
    $result = $modelObj->runQuery($qry); 
    
    $userimgdetail = $commoncont -> getuserimagedetailbyid($tabval);
    //print_r($userimgdetail);
    $itemhtml = '<div class="col-lg-3 col-md-3 col-xs-6 preview-item ui-state-default" style="min-height: 225px; background-image: url(\''.$_SESSION['SITE_NAME'].'upload/images/300/'.$userimgdetail['image'].'\'); background-size: cover; background-repeat: no-repeat; background-position: 50% 50%;" data-tabval="'.$userimgdetail['id'].'">
          <a href="'.$_SESSION['FRNT_DOMAIN_NAME'].'editimage/'.$userimgdetail['id'].'"><i class="fa fa-pencil-square-o edit-icon" title="Edit image"></i></a>
          <i class="fa fa-times-circle remove-cross" title="Hide image"></i>
          <a href="javascript:void(0)" onclick="openuserimageinpopup(\''.$userimgdetail['id'].'\')" class="openpop-link">&nbsp;</a>
          <!--<a>
              <img src="'.$_SESSION['SITE_NAME'].'upload/images/300/'.$userimgdetail['image'].'" alt="..." class="example-image img-responsive" />
          </a>

          <h3>
              '.$userimgdetail['img_title'].'
          </h3>  -->  
          <input type="checkbox" id="imgchk'.$userimgdetail['id'].'" class="actionchk" title="Select" value="'.$userimgdetail['id'].'" />
      </div>';
    echo $itemhtml;
    exit;
endif;
if(isset($_POST['addnewsubcatchk']) && $_POST['addnewsubcatchk'] != ''):
    $subcattitle = $_POST['subcattitle'];
    $subcatcatid = $_POST['subcatcatid'];
    
    $qry="INSERT INTO tbl_users_sub_categories (`cat_id`, `user_id`, `sub_category_title`, `cr_date`, `status`) VALUES('".clear_input($subcatcatid)."', '".clear_input($_SESSION['po_userses']['flc_usrlogin_id'])."', '".clear_input($subcattitle)."', NOW(), 1) ";
    $result = $modelObj->runQuery($qry); 
    $lastinsertedid = mysql_insert_id();
    echo $lastinsertedid;
    exit;
endif;
if(isset($_POST['dltnewsubcatchk']) && $_POST['dltnewsubcatchk'] != ''):
    $dltstbcatcat = $_POST['dltstbcatcat'];
    
    $qry="DELETE FROM tbl_users_sub_categories WHERE id = '".clear_input($dltstbcatcat)."' ";
    $result = $modelObj->runQuery($qry); 

    if($result){
      $qry="DELETE FROM tbl_users_sub_category_images WHERE subcat_id = '".clear_input($dltstbcatcat)."' ";
      $result = $modelObj->runQuery($qry);
    }

    echo 1;
    exit;
endif;
if(isset($_POST['loadsubcatimageschk']) && $_POST['loadsubcatimageschk'] != ''):
    $subcat = $_POST['subcat'];
    $cat = $_POST['cat'];
    
    $modcnt = 0; 
    $itemhtml = '';
    $imglist = $commoncont -> getimagesbySubcatCatUserid($_SESSION['po_userses']['flc_usrlogin_id'], $cat, $subcat);
    if(!empty($imglist)):
        foreach ($imglist as $k => $imgsdata):

          $itemhtml .= '<div class="col-lg-3 col-md-3 col-xs-6 preview-item ui-state-default" style="min-height: 225px; background-image: url(\''.$_SESSION['SITE_NAME'].'upload/images/300/'.$imgsdata['image'].'\'); background-size: cover; background-repeat: no-repeat; background-position: 50% 50%;" data-tabval="'.$imgsdata['id'].'">
                <a href="'.$_SESSION['FRNT_DOMAIN_NAME'].'editimage/'.$imgsdata['id'].'"><i class="fa fa-pencil-square-o edit-icon" title="Edit image"></i></a>
                <i class="fa fa-times-circle remove-cross" title="Hide image"></i>
                <a href="javascript:void(0)" onclick="openuserimageinpopup(\''.$imgsdata['id'].'\')" class="openpop-link">&nbsp;</a>
                <!--<a>
                    <img src="'.$_SESSION['SITE_NAME'].'upload/images/300/'.$imgsdata['image'].'" alt="..." class="example-image img-responsive" />
                </a>

                <h3>
                    '.$imgsdata['img_title'].'
                </h3>  -->  
                <input type="checkbox" id="imgchk'.$imgsdata['id'].'" class="actionchk" title="Select" value="'.$imgsdata['id'].'" />
            </div>';
        endforeach;
    else: 
        $itemhtml .= '<div class="callout callout-info">
            <h4>No Image Found</h4>
            <p><i class="fa fa-info-circle"></i> There is no image under this category to show.</p>            
        </div>';
    endif; 
    
    echo $itemhtml;
    exit;
endif;
if(isset($_POST['getsubcatoptionlistchk']) && $_POST['getsubcatoptionlistchk'] != ''):
  
    $selcatid = $_POST['selcatid'];
  
    $subcatlist = $commoncont -> getsubcategorylistbyusercatids($_SESSION['po_userses']['flc_usrlogin_id'], $selcatid);
    $optionlist = '<option value="">Select Action</option>';
    foreach ($subcatlist as $key => $subcats) {
      $optionlist .= '<option value="'.$subcats['id'].'">'.$subcats['sub_category_title'].'</option>';
    }
    echo $optionlist;
    exit;
endif;
if(isset($_POST['proccatbulkactionchk']) && $_POST['proccatbulkactionchk'] != ''):
  
    $chklist = explode(",", $_POST['chklist']);
    $catdata = $_POST['catdata'];
    $subcati = $_POST['subcati'];
    $bulkact = $_POST['bulkact'];
  
    if($chklist != '' && $catdata != '' && $subcati != '' && $bulkact != ''){
      foreach ($chklist as $key => $imgdata) {
        $chkifexist = $commoncont -> checkifimageexistinsubcat($_SESSION['po_userses']['flc_usrlogin_id'], $catdata, $subcati, $imgdata);
        
        if($bulkact == 'move'){
          $commoncont -> removeimagefromallsubcategory($_SESSION['po_userses']['flc_usrlogin_id'], $catdata, $subcati, $imgdata);
          $commoncont -> addimagetosubcategory($_SESSION['po_userses']['flc_usrlogin_id'], $catdata, $subcati, $imgdata);
        }elseif($bulkact == 'add' && $chkifexist == 0){
          $commoncont -> addimagetosubcategory($_SESSION['po_userses']['flc_usrlogin_id'], $catdata, $subcati, $imgdata);
        }
      }
    }

    echo 1;
    exit;
endif;
if(isset($_POST['procrmvimgfrmsubcatchk']) && $_POST['procrmvimgfrmsubcatchk'] != ''):
  
    $chklist = explode(",", $_POST['chklist']);
    $catdata = $_POST['catdata'];
    $subcati = $_POST['subcati'];
    $bulkact = $_POST['bulkact'];
  
    if($chklist != '' && $catdata != '' && $subcati != '' && $bulkact != ''){
      foreach ($chklist as $key => $imgdata) {
        $commoncont -> removeimagefromsubcategory($_SESSION['po_userses']['flc_usrlogin_id'], $catdata, $subcati, $imgdata);
      }
    }

    echo 1;
    exit;
endif;
if(isset($_POST['getuserimagedatachk']) && $_POST['getuserimagedatachk'] != ''):
    $usrimgid = $_POST['usrimgid'];
    $userimgdetail = $commoncont -> getuserimagedetailbyid($usrimgid);
    $imgcurrency = $commoncont -> getcurrencydetailbyid($userimgdetail['price_currency']);

    if($userimgdetail['is_sold'] == 1): 
      $issold = '<button class="col-xs-12 margin-top-10 btn btn-danger btn_sold_img">SOLD</button> &nbsp;';
    else:
      $issold = '<button class="col-xs-12 margin-top-10 btn btn-success" >For Sale</button> &nbsp;';
    endif;
    $imgprice = '<button class="col-xs-12 margin-top-10 btn btn-warning" >'.$imgcurrency['cur_text'].$userimgdetail['img_price'].'</button> &nbsp;';

    echo $usrimgpopcnt = '<div class="col-lg-8 col-md-8 col-xs-12 portfolio-item">
              <div class=" col-xs-12 zoom img-to-zoom" id="img-to-zoom-'.$userimgdetail['id'].'"><img class="example-image img-responsive" id="inline-pop-img-'.$userimgdetail['id'].'-img" alt="..." src="'.$_SESSION['SITE_NAME'].'upload/images/'.$userimgdetail['image'].'"><!--<p>Click to zoom</p>--></div>
          </div>
          <div class="col-lg-4 col-md-4 col-xs-12 portfolio-item">
        <h3>
          '.$userimgdetail['img_title'].'
        </h3>
        <p>'.$userimgdetail['image_text'].'</p>
        '.$issold.'
        '.$imgprice.'
        <div style="clear:both;"></div>
      </div>';
    
  //echo 1;
  exit;
endif;
?>