<?php
class EditimageController extends CommonController
{
	function __construct()
	{
		parent::__construct();
		$this -> modelObj = new EditimageModel();

		if(!isset($_GET['workid']) || $_GET['workid'] == ''):
			$this -> redirecttohomepage();
		endif;

		if(isset($_POST) && isset($_POST['btn_editimage_info']) && $_POST['txt_img_title'] != ''):
			$usr_insert_img = $this -> updateuserimage($_POST['txt_img_title'], $_POST['txt_img_text'], $_POST['sel_currency'], $_POST['txt_img_price'], $_POST['sel_category']);
			header("Location: ".$_SESSION['FRNT_DOMAIN_NAME']."preview");
		endif;

		$this -> getartistimgdetails = $this -> getuserimagedetailbyid($_GET['workid']);
		$this -> gtcategory = $this -> getcategorylist($this -> gtplans['category']);
	}

	function updateuserimage($imgtitle, $imgtext, $currency, $imgprice, $catid, $imglimit){
		$qry = "UPDATE `tbl_user_images` SET `img_title` = '".clear_input($imgtitle)."', `image_text` = '".clear_input($imgtext)."', `price_currency` = '".clear_input($currency)."', `img_price` = '".clear_input($imgprice)."', `category_id` = '".clear_input($catid)."' WHERE id = '".$_GET['workid']."' ";
		$result = $this->modelObj->runQuery($qry);

		return $result;
	}
}
?>